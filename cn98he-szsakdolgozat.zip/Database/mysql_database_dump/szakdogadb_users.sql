-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: szakdogadb
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(45) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(45) NOT NULL,
  `has_picture` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name_UNIQUE` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Hajas Bandor Mester','bandormester','248b646537648c1fbdeb42b56771dbdb42129e8bab527ff551a1f49ce499464f','prob@asd.com',1),(2,'newuser','newuser','newpassword','newemail',1),(3,'asd','asd','asd','asd',0),(4,'newuser','newuser3','newpassword','newemail',0),(14,'newuser','newuser2','newpassword','newemail',0),(23,'asd','asd2','asd','asd',0),(24,'asd','asd22','asd','asd',0),(26,'asd','asd223','asd','asd',0),(27,'asd','123','asd','asd',0),(28,'asd','4444','asd','asd',0),(31,'asd','44445','asd','asd',0),(33,'asd','asd123','asd','asd',0),(34,'asd','asd12345','asd','asd',0),(36,'asd','12345asd','asd','asd',0),(40,'newuser','newuser34','newpassword','newemail',0),(44,'newuser','newuser34asd','newpassword','newemail',0),(46,'asd','asd12314124','asd','asd',0),(49,'asd','asd123444444','asd','asd',0),(50,'asd','1231254125asf','asd','asd',0),(56,'asd','asdggggggggggg','asd','asd',1),(58,'asd','asdggggggggggga','asd','asd',1),(59,'1234','1234','123','1245',0),(61,'1234','12345','123','1245',0),(62,'1234','123456','123','1245',1),(64,'asd','asdfgh','asd','asd',0),(66,'asd','asdfghg','asd','asd',0),(68,'newuser','newuser34asd123','newpassword','newemail',0),(73,'asd','asdlkj','asd','asd',0),(76,'asd','asd4444444','asd','asd',0),(77,'asd','asd12344444','asd','asd',0),(78,'asd','asd444444444444444','asd','asd',0),(79,'asd','asdfffffffffff','asd','asd',0),(80,'fn','demo','demo','demo',0),(81,'Ferenc','Feri','688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6','a@a.hu',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-11  8:20:17
