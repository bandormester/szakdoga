-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: szakdogadb
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int NOT NULL,
  `group_id` int NOT NULL,
  `label` varchar(64) NOT NULL,
  `importance` varchar(64) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `deadline` double DEFAULT NULL,
  `has_assignee` tinyint(1) NOT NULL DEFAULT '0',
  `has_checklist` tinyint(1) NOT NULL DEFAULT '0',
  `state` varchar(45) NOT NULL DEFAULT 'SAVED',
  PRIMARY KEY (`id`),
  KEY `GROUP` (`group_id`) /*!80000 INVISIBLE */,
  KEY `OWNER` (`group_id`,`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,1,6,'assignee','IMPORTANT','',NULL,NULL,NULL,1,1,'SAVED'),(2,1,6,'asd','IMPORTANT','',19.154786440123793,11.582729034125805,NULL,1,1,'SAVED'),(3,1,6,'asd','IMPORTANT','',19.154786440123793,11.582729034125805,NULL,1,1,'SAVED'),(5,2,6,'not owned','REGULAR','not owned',NULL,NULL,NULL,0,0,'DONE'),(20,1,6,'Kivinni a szemetet','REGULAR','',46.0714189,18.2300453,NULL,1,1,'OPEN'),(21,1,6,'Dokumentáció elkeszitese','CRUCIAL','Szakdogahoz tartozó doksit kénghzzzzeajajaj elkészíteni időben',17.942783425980725,-0.42246099561452866,NULL,1,1,'OPEN'),(23,1,6,'Feladatcim','IMPORTANT','Leiras',47.4506144,18.9639453,NULL,1,1,'OPEN'),(24,1,6,'Az új feladat címe','IMPORTANT',NULL,47.4506144,18.9639453,NULL,1,1,'OPEN');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-11  8:20:17
