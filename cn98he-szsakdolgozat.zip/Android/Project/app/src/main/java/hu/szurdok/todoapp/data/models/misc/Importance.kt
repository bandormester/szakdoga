package hu.szurdok.todoapp.data.models.misc

enum class Importance {
    CRUCIAL,
    IMPORTANT,
    REGULAR
}