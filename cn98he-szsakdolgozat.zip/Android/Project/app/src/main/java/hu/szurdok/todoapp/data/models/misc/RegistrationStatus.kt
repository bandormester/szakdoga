package hu.szurdok.todoapp.data.models.misc

import hu.szurdok.todoapp.TodoApplication

data class RegistrationStatus (
    val successful : Boolean,
    val message : String
){}