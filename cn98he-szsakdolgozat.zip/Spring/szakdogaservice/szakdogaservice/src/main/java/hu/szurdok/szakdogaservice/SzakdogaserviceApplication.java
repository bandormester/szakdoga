package hu.szurdok.szakdogaservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SzakdogaserviceApplication {

	public static void main(String[] args)
	{
		SpringApplication.run(SzakdogaserviceApplication.class, args);
	}

}
