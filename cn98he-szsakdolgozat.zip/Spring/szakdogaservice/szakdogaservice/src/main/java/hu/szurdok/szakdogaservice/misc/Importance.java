package hu.szurdok.szakdogaservice.misc;

public enum Importance {
    CRUCIAL,
    IMPORTANT,
    REGULAR
}
