package hu.szurdok.szakdogaservice.misc;

public enum TaskState {
    SAVED,
    DONE,
    OPEN
}
